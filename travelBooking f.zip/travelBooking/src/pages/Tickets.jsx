import React from 'react'
import Header from '../Components/Header'
import TicketBookings from '../Components/TicketBookings'
import Footer from '../Components/Footer'

function Tickets() {
  return (
    <>
     <Header/>
     <TicketBookings/>
     <Footer/>
    </>
  )
}

export default Tickets