import Header from "../Components/Header";
import Footer from "../Components/Footer";
import Bookings from "../Components/Bookings";

function BookingPage() {
  return (
    <>
      <Header />
      <Bookings />
      <Footer />
    </>
  );
}

export default BookingPage;
