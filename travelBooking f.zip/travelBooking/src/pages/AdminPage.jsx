import React from "react";
import Header from "../Components/Header";
import AdminPanel from "../Components/AdminPanel";
import Footer from "../Components/Footer";

function AdminPage() {
  return (
    <>
      <Header />
      <AdminPanel/>
      <Footer/>
    </>
  );
}

export default AdminPage;
