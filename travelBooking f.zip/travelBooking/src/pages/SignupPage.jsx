import React from 'react'
import Header from '../Components/Header'
import Signup from '../Components/Signup'

function SignupPage() {
  return (
    <>
    <Signup/>
    </>
  )
}

export default SignupPage