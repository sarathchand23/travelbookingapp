import Header from "../Components/Header";
import Footer from "../Components/Footer";
import TripSection from "../Components/TripSection";
import HeroSection from "../Components/HeroSection";
function Home() {
  return (
    <>
      <Header />
      <HeroSection />
      <TripSection/>
      <Footer />
    </>
  );
}

export default Home;
