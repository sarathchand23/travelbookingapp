import React from 'react'
import Header from '../Components/Header'
import Tour from '../Components/Tour'
import Footer from '../Components/Footer'
import Booking from '../Components/Booking'

function TourPage() {
  return (
    <>
        <Header/>
        <Tour/>
        <Booking/>
        <Footer/>
    </>
  )
}

export default TourPage