import "./App.css";
import Routes from "./Routes/Routing";

function App() {
  return (
    <>

      <Routes/>

    </>
  );
}

export default App;
