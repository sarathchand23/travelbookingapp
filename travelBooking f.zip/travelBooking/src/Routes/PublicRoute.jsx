import React from 'react'

function PublicRoute() {
  return (
    <>
    
    </>
  )
}

export default PublicRoute