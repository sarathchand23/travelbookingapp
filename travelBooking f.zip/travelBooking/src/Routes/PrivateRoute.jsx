import { useNavigate } from "react-router-dom";

export const PrivateRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  const userInfo = localStorage.getItem("userInfo");
  const navigate = useNavigate();

  if (!token) {
    navigate("/"); // Redirect to login if no token
    return null;
  }

  // Check if the child element is a Route
  if (children.props && children.props.path === "/admin") {
    // Check if userInfo is available and the user is not an admin
    if (userInfo && userInfo.role !== "Admin") {
      navigate("/home"); // Redirect non-admins from "/admin" to "/home"
      return null;
    }
  }

  return children;
};
