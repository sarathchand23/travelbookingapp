import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Home from "../pages/Home";
import LoginPage from "../pages/LoginPage";
import SignupPage from "../pages/SignupPage";
import AdminPage from "../pages/AdminPage";
import TourPage from "../pages/TourPage";
import BookingsPage from "../pages/BookingsPage";
import Tickets from "../pages/Tickets";

function Routing() {
  const token = localStorage.getItem("token");
  const userInfo = JSON.parse(localStorage.getItem("userInfo")); // Parse userInfo

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        {token ? (
          <Route path="/home" element={<Home />} />
        ) : (
          <Route path="*" element={<Navigate to="/" />} />
        )}
        {token ? (
          <Route path="/tour/view/:id" element={<TourPage />} />
        ) : (
          <Route path="*" element={<Navigate to="/" />} />
        )}
        {token ? (
          <Route path="/bookings" element={<BookingsPage />} />
        ) : (
          <Route path="*" element={<Navigate to="/" />} />
        )}
             {token ? (
          <Route path="/tickets" element={<Tickets />} />
        ) : (
          <Route path="*" element={<Navigate to="/" />} />
        )}
        {userInfo.role === "Admin" ? (
          <Route path="/admin" element={<AdminPage />} />
        ) : (
          <Route path="*" element={<Navigate to="/" />} />
        )}
        <Route path="/signup" element={<SignupPage />} />
      </Routes>
    </BrowserRouter>
  );
}
export default Routing;
