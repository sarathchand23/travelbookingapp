import { useEffect, useState } from "react";
import { Card, CardBody, CardSubtitle, CardText, CardTitle, Container } from "reactstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { formatCurrency } from "../utilities/formatCurrency";

function TripSection() {
  const [trips, setTrips] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    fetchTrips();
  }, []);

  const fetchTrips = async () => {
    try {
      const response = await axios.get(
        "http://localhost/travelBooking/tour.php"
      );
      setTrips(response.data);
    } catch (error) {
      console.error("Error fetching trips:", error);
    }
  };

  return (
    <div>
      <Container>
        <h1 className="text-center pt-5">
          Select from Wide range of Tour Packages
        </h1>
        <div className="d-flex justify-content-center align-items-center gap-3 flex-wrap py-5">
          {trips.map((trip) => (
            <Card
              key={trip.id}
              style={{ width: "20rem", cursor: "pointer" }}
              onClick={() => navigate(`/tour/view/${trip.id}`)}
            >

              <img
                alt={trip.nameOfTheTrip}
                src={trip?.tripImage}
                width="100%"
                className="rounded-top"
              />
              <CardBody className="d-flex flex-column  py-3">
                <CardTitle tag="h5">{trip.nameOfTheTrip}</CardTitle>
                <CardSubtitle className="mb-2 text-muted" tag="h6">
                  {trip.noOfDays} Days {trip.noOfNights} Nights
                </CardSubtitle>
                <CardSubtitle className="mb-2 text-muted" tag="h6">
                  Available for {trip.allowedBookings} People
                </CardSubtitle>
                <CardText className="fs-5 fw-bold">
                  {formatCurrency(trip.price)} /person
                </CardText>
      
              </CardBody>
            </Card>
          ))}
        </div>
      </Container>
    </div>
  );
}

export default TripSection;
