import { useEffect, useState } from "react";
import {
  Nav,
  NavItem,
  NavLink,
  TabContent,
  TabPane,
  Form,
  Input,
  Button,
  FormGroup,
  Label,
  CardBody,
  Card,
} from "reactstrap";
import { FaTrain, FaBusAlt, FaCar } from "react-icons/fa";
import { RiFlightTakeoffFill } from "react-icons/ri";
import "react-datepicker/dist/react-datepicker.css";
import { formatCurrency } from "../utilities/formatCurrency";
import ReactDatePicker from "react-datepicker";

function TicketSearch(props) {
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [activeTab, setActiveTab] = useState("trains");
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [travelDate, setTravelDate] = useState(new Date());
  const [userId, setUserId] = useState(null);
  const [userEmail, setUserEmail] = useState(null);

  const [selectedSeat, setSelectedSeat] = useState(null);

  const [participants, setParticipants] = useState([
    { name: "", age: "", gender: "", phone: "" },
  ]);
  const [data, setData] = useState();

  const [paymentStatus, setPaymentStatus] = useState("");
  const [paymentId, setPaymentId] = useState("");
  useEffect(() => {
    // Retrieve user ID from local storage
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    if (userInfo && userInfo.user_id) {
      setUserId(userInfo.user_id);
      setUserEmail(userInfo.user_email);
    }

    // Fetch tour price
  }, []); // Fetch tour price whenever ID changes

  const handleParticipantChange = (index, field, value) => {
    const updatedParticipants = [...participants];
    updatedParticipants[index] = {
      ...updatedParticipants[index],
      [field]: value,
    };
    setParticipants(updatedParticipants);
  };

  const sendDataToServer = async (data) => {
    try {
      // Add recipient email to the formData

      const response = await fetch(
        "http://localhost/travelBooking/travelTicket.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      if (response.ok) {
        console.log("Data sent successfully");
        // Handle success
      } else {
        console.error("Failed to send data");
        // Handle failure
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };
  const handleSubmitBooking = async (data) => {
    const formattedTravelDate = `${travelDate.getFullYear()}-${(
      travelDate.getMonth() + 1
    )
      .toString()
      .padStart(2, "0")}-${travelDate.getDate().toString().padStart(2, "0")}`;

    const requestData = {
      user_id: userId, // Assuming this is a static value
      participants: participants.map((participant) => ({
        name: participant.name,
        age: parseInt(participant.age),
        phone: participant.phone,
      })),
      travel_option_id: data.id, // Assuming data is the response from the API
      bus_seat: selectedSeat === "bus",
      flight_seat: selectedSeat === "flight",
      train_seat: selectedSeat === "train",
      cab_seat: selectedSeat === "cabs",

      paymentStatus: paymentStatus,
      paymentId: paymentId,
      travel_date: formattedTravelDate, // Pass formatted travelDate here
    };
    let selectedOptionPrice = 0;
    switch (selectedSeat) {
      case "bus":
        selectedOptionPrice = data.bus_price;
        break;
      case "train":
        selectedOptionPrice = data.train_price;
        break;
      case "flight":
        selectedOptionPrice = data.flight_price;
        break;
        case "cabs":
        selectedOptionPrice = data.cab_price;
        break;
      default:
        // Handle default case or show an error
        break;
    }

    const options = {
      key: "rzp_test_wywb8ONB6LP3HN",
      amount: selectedOptionPrice * numberOfPeople * 100, // Amount in paise
      currency: "INR",
      name: "Your Travel Company",
      description: "Tour Booking",
      image: "/your_logo.png",
      handler: function (response) {
        if (response.razorpay_payment_id) {
          requestData.paymentStatus = "success";
          setPaymentStatus("success");
          requestData.paymentId = response.razorpay_payment_id;
          setPaymentId(response.razorpay_payment_id);
        } else {
          requestData.paymentStatus = "fail";
          requestData.paymentId = ""; // Reset paymentId in case of error
        }
        sendDataToServer(requestData);
      },

      prefill: {
        name: "Customer Name",
        email: userEmail,
        contact: "9999999999",
      },
      theme: {
        color: "#3399cc",
      },
    };

    const rzp = new Razorpay(options);
    rzp.open();
  };
  const toggleTab = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
    // handleSeatSelection(tab)
  };
  const handleSeatSelection = (seat) => {
    console.log(seat);
    setSelectedSeat(seat);
  };

  const fetchData = async () => {
    try {
      const response = await fetch(
        `http://localhost/travelBooking/ticketBooking.php?origin=${origin}&destination=${destination}`
      );
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleNumberOfPeopleChange = (e) => {
    const numPeople = parseInt(e.target.value);
    setNumberOfPeople(numPeople);

    // Update participants array to match the number of people
    const updatedParticipants = [];
    for (let i = 0; i < numPeople; i++) {
      updatedParticipants.push({
        name: "",
        age: "",
        gender: "",
        phone: "",
      });
    }
    setParticipants(updatedParticipants);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="py-5">
      <div className="bg-white py-3 rounded shadow-md">
        <Nav tabs className="p-3">
          <NavItem className="">
            <NavLink
              className={activeTab === "trains" ? "active" : ""}
              onClick={() => toggleTab("trains")}
              style={{ cursor: "pointer" }}
            >
              Trains <FaTrain />
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              className={activeTab === "buses" ? "active" : ""}
              onClick={() => toggleTab("buses")}
              style={{ cursor: "pointer" }}
            >
              Buses <FaBusAlt />
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              className={activeTab === "flights" ? "active" : ""}
              onClick={() => toggleTab("flights")}
              style={{ cursor: "pointer" }}
            >
              Flights <RiFlightTakeoffFill />
            </NavLink>
          </NavItem>
          <NavItem className="">
            <NavLink
              className={activeTab === "cabs" ? "active" : ""}
              onClick={() => toggleTab("cabs")}
              style={{ cursor: "pointer" }}
            >
              Cabs <FaCar />
            </NavLink>
          </NavItem>
        </Nav>
        <div className=" rounded-bottom-5 p-5">
          <Form onSubmit={handleSubmit} className="">
            <div className="d-flex gap-5 flex-col justify-content-around align-items-">
              <Input
                id="origin Input"
                name="origin"
                placeholder="Origin"
                type="text"
                className=" border-dark"
                value={origin}
                required
                onChange={(e) => setOrigin(e.target.value)}
              />
              <Input
                id="destination Input"
                name="destination"
                placeholder="Destination"
                type="text"
                className=" border-dark"
                value={destination}
                required
                onChange={(e) => setDestination(e.target.value)}
              />

              <Button
                type="submit"
                className="w-100"
                onClick={() => fetchData()}
              >
                Search For Tickets
              </Button>
            </div>
          </Form>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="trains">
              {data && data.message ? (
                <div className="error-message pt-5">{data.message}</div>
              ) : (
                <>
                  <h4 className="pt-3">{data ? "Available Trains" : ""}</h4>
                  {data &&
                    data?.map((item) => (
                      <div
                        key={item?.id}
                        className="py-2 d-flex justify-content-around  gap-4"
                      >
                        <Card className="p-3 w-100 ">
                          <CardBody className=" justify-content-between ">
                            <div className="d-flex justify-content-between">
                              <h6>{item.train_name}</h6>
                              <div className="d-flex gap-3">
                                <h6> {item.start_date}</h6>
                                <h6>-</h6>
                                <h6>{item.end_date}</h6>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <p>
                                Available Seats: {item.train_seats_available}
                              </p>
                              <p>
                                Price: {formatCurrency(item.train_price)}{" "}
                                /Person
                              </p>
                            </div>
                            <div className="text-end">
                              <Button
                                onClick={() => handleSeatSelection("train")}
                              >
                                Select This
                              </Button>
                            </div>
                          </CardBody>
                        </Card>
                      </div>
                    ))}
                </>
              )}
            </TabPane>
            <TabPane tabId="buses">
              {data && data.message ? (
                <div className="error-message pt-5">{data.message}</div>
              ) : (
                <>
                  <h4 className="pt-3">{data ? "Available Buses" : ""}</h4>
                  {data &&
                    data?.map((item) => (
                      <div
                        key={item.id}
                        className="py-2 d-flex justify-content-around  gap-4"
                      >
                        <Card className="p-3 w-100 ">
                          <CardBody className=" justify-content-between ">
                            <div className="d-flex justify-content-between">
                              <h6>{item.bus_name}</h6>
                              <div className="d-flex gap-3">
                                <h6> {item.start_date}</h6>
                                <h6>-</h6>
                                <h6>{item.end_date}</h6>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <p>Available Seats: {item.bus_seats_available}</p>
                              <p>
                                Price: {formatCurrency(item.bus_price)} /Person
                              </p>
                            </div>
                            <div className="text-end">
                              <Button
                                onClick={() => handleSeatSelection("bus")}
                              >
                                Select This
                              </Button>
                            </div>
                          </CardBody>
                        </Card>
                      </div>
                    ))}
                </>
              )}
            </TabPane>
            <TabPane tabId="flights">
              {data && data.message ? (
                <div className="error-message pt-5">{data.message}</div>
              ) : (
                <>
                  <h4 className="pt-3">{data ? "Available Flights" : ""}</h4>
                  {data &&
                    data?.map((item) => (
                      <div
                        key={item.id}
                        className="py-2 d-flex justify-content-around  gap-4"
                      >
                        <Card className="p-3 w-100 ">
                          <CardBody className=" justify-content-between ">
                            <div className="d-flex justify-content-between">
                              <h6>{item.flight_name}</h6>
                              <div className="d-flex gap-3">
                                <h6> {item.start_date}</h6>
                                <h6>-</h6>
                                <h6>{item.end_date}</h6>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <p>
                                Available Seats: {item.flight_seats_available}
                              </p>
                              <p>
                                Price: {formatCurrency(item.flight_price)}{" "}
                                /Person
                              </p>
                            </div>
                            <div className="text-end">
                              <Button
                                onClick={() => handleSeatSelection("flight")}
                              >
                                Select This
                              </Button>
                            </div>
                          </CardBody>
                        </Card>
                      </div>
                    ))}
                </>
              )}
            </TabPane>
            <TabPane tabId="cabs">
              {data && data.message ? (
                <div className="error-message pt-5">{data.message}</div>
              ) : (
                <>
                  <h4 className="pt-3">{data ? "Available Cabs" : ""}</h4>
                  {data &&
                    data?.map((item) => (
                      <div
                        key={item.id}
                        className="py-2 d-flex justify-content-around  gap-4"
                      >
                        <Card className="p-3 w-100 ">
                          <CardBody className=" justify-content-between ">
                            <div className="d-flex justify-content-between">
                              <h6>{item.cab_name}</h6>
                              <div className="d-flex gap-3">
                                <h6> {item.start_date}</h6>
                                <h6>-</h6>
                                <h6>{item.end_date}</h6>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <p>
                                Available Seats: {item.cab_seats_available}
                              </p>
                              <p>
                                Price: {formatCurrency(item.cab_price)}{" "}
                                /Person
                              </p>
                            </div>
                            <div className="text-end">
                              <Button
                                onClick={() => handleSeatSelection("cabs")}
                              >
                                Select This
                              </Button>
                            </div>
                          </CardBody>
                        </Card>
                      </div>
                    ))}
                </>
              )}
            </TabPane>
          </TabContent>
        </div>
      </div>

      <div className="py-5 bg-white p-5 ">
        <FormGroup>
          <Label for="numberOfPeople">Number of People:</Label>
          <Input
            type="number"
            id="numberOfPeople"
            min={2}
            name="numberOfPeople"
            value={numberOfPeople}
            onChange={handleNumberOfPeopleChange}
          />
        </FormGroup>
        <Label>Choose Date of Travel</Label>
        <br />
        <ReactDatePicker
          selected={travelDate}
          onChange={(date) => setTravelDate(date)}
          className="form-control mb-3"
        />

        {participants.map((participant, index) => (
          <div key={index}>
            <FormGroup>
              <Label for={`name${index}`}>{`Enter details of person ${
                index + 1
              }`}</Label>
              <Input
                type="text"
                id={`name${index}`}
                name={`name${index}`}
                value={participant.name}
                onChange={(e) =>
                  handleParticipantChange(index, "name", e.target.value)
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for={`age${index}`}>Age:</Label>
              <Input
                type="number"
                id={`age${index}`}
                name={`age${index}`}
                value={participant.age}
                min={1}
                max={90}
                onChange={(e) =>
                  handleParticipantChange(index, "age", e.target.value)
                }
              />
            </FormGroup>
            <FormGroup>
              <Label for={`phone${index}`}>Phone:</Label>
              <Input
                type="number"
                id={`phone${index}`}
                name={`phone${index}`}
                value={participant.phone}
                onChange={(e) =>
                  handleParticipantChange(index, "phone", e.target.value)
                }
              />
            </FormGroup>
            <FormGroup tag="fieldset">
              <legend>Gender:</legend>
              <FormGroup check>
                <Label check>
                  <Input
                    type="radio"
                    name={`gender${index}`}
                    value="male"
                    checked={participant.gender === "male"}
                    onChange={(e) =>
                      handleParticipantChange(index, "gender", e.target.value)
                    }
                  />{" "}
                  Male
                </Label>
              </FormGroup>
              <FormGroup check>
                <Label check>
                  <Input
                    type="radio"
                    name={`gender${index}`}
                    value="female"
                    checked={participant.gender === "female"}
                    onChange={(e) =>
                      handleParticipantChange(index, "gender", e.target.value)
                    }
                  />{" "}
                  Female
                </Label>
              </FormGroup>
            </FormGroup>
          </div>
        ))}
        <Button
          onClick={() =>
            data.length > 0 && data[0].id && handleSubmitBooking(data[0])
          }
        >
          Book Now
        </Button>
      </div>
    </div>
  );
}

export default TicketSearch;
