import React from "react";

function Footer() {
  return (
    <>
      <div className="bg-warning-subtle ">
        <div className="h-100 w-100 container py-5">
          <div className="d-flex justify-content-between flex-wrap">
            <div>Travel Booking</div>
            <div>
              <div>Home</div>
              <div>Bookings</div>
            </div>
            <div></div>
            <div></div>
            <div></div>
          </div>
          <div className="text-center pt-5">
            All Rights Reserved copyrights &copy;Travel Booking 2024
          </div>
        </div>
      </div>
    </>
  );
}

export default Footer;
