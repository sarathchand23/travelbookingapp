import { useState, useEffect } from "react";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import { useNavigate } from "react-router-dom";
import "../index.css";
import "../App.css";
import Logo from "../assets/logo.jpg";
function Header(args) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [tourPackages, setTourPackages] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if token is present in localStorage
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // Set isLoggedIn based on presence of token

    // Fetch tour packages data
    fetch("http://localhost/travelBooking/tour.php")
      .then((response) => response.json())
      .then((data) => {
        setTourPackages(data);
      })
      .catch((error) => {
        console.error("Error fetching tour packages:", error);
      });
  }, []);

  const toggle = () => setIsOpen(!isOpen);

  const handleLogout = () => {
    // Remove token from localStorage
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    // Redirect to login page
    navigate("/");
  };

  return (
    <div className="headerContainer bg-warning shadow-lg sticky-top py-3 ">
      <Navbar {...args} light expand="md" className="container">
        <NavbarBrand
          href="/"
          className="mx-auto fw-bold text-white text-uppercase"
        >
          <img src={Logo} alt=""  width={100}/>
        </NavbarBrand>
        <NavbarToggler
          onClick={toggle}
          className="text-white bg-warning-subtle"
        />
        <Collapse isOpen={isOpen} navbar className="ms-5">
          <Nav className="ms-auto d-flex gap-2" navbar>
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle
                nav
                caret
                className="fw-bolder text-uppercase text-white fs-5 nav-item"
              >
                Tour Packages
              </DropdownToggle>

              <DropdownMenu end className="">
                {tourPackages.map((pack) => (
                  <DropdownItem
                    key={pack.id}
                    onClick={() => navigate(`/tour/view/${pack.id}`)}
                  >
                    {pack.nameOfTheTrip}
                  </DropdownItem>
                ))}
              </DropdownMenu>
            </UncontrolledDropdown>

            <NavItem>
              <NavLink
                href="/"
                className="fw-bolder text-uppercase text-white fs-5"
              >
                Home
              </NavLink>
            </NavItem>
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle
                nav
                caret
                className="fw-bolder text-uppercase text-white fs-5 nav-item"
              >
                More
              </DropdownToggle>

              <DropdownMenu end className="">
                <DropdownItem onClick={() => navigate("/bookings")}>
                  Bookings
                </DropdownItem>
                <DropdownItem onClick={()=>navigate("/tickets")}>Tickets</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>

            {isLoggedIn ? (
              <NavLink
                onClick={handleLogout}
                className="fw-bolder text-uppercase text-white fs-5 nav-item"
                style={{ cursor: "pointer" }}
              >
                Logout
              </NavLink>
            ) : (
              <NavLink
                href="/"
                style={{ cursor: "pointer" }}
                className="fw-bolder text-uppercase text-white fs-5 nav-item"
              >
                Login
              </NavLink>
            )}
          </Nav>
        </Collapse>
      </Navbar>
    </div>
  );
}

export default Header;
