import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button, Container, Form, FormGroup, Input, Label } from "reactstrap";

function Booking() {
  const { id } = useParams();
  const [userId, setUserId] = useState(null);
  const [recipientEmail, setRecipientEmail] = useState(null);
  const [tourPrice, setTourPrice] = useState(0);
  const [groupTravel, setGroupTravel] = useState(false);
  const [soloTravel, setSoloTravel] = useState(true);
  const [joinGroup, setJoinGroup] = useState(false); // New state for joining group
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [participants, setParticipants] = useState([{ name: "", age: "", gender: "", phone: "" }]);
  const [paymentStatus, setPaymentStatus] = useState("success");
  const [paymentId, setPaymentId] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    if (userInfo && userInfo.user_id) {
      setUserId(userInfo.user_id);
      setRecipientEmail(userInfo.email);
    }
    fetchTourPrice();
  }, [id]);

  const fetchTourPrice = async () => {
    try {
      const response = await fetch(`http://localhost/travelBooking/tour.php?id=${id}`);
      const data = await response.json();
      if (data && data.price) {
        setTourPrice(data.price);
      }
    } catch (error) {
      console.error("Error fetching tour price:", error);
    }
  };

  const handleGroupTravelChange = (e) => {
    setGroupTravel(e.target.checked);
    setSoloTravel(!e.target.checked);
  };

  const handleSoloTravelChange = (e) => {
    setSoloTravel(e.target.checked);
    setGroupTravel(!e.target.checked);
    // Reset joinGroup state when solo travel is selected
    setJoinGroup(false);
  };

  const handleJoinGroupChange = (e) => {
    setJoinGroup(e.target.checked);
  };

  const handleNumberOfPeopleChange = (e) => {
    const numPeople = parseInt(e.target.value);
    setNumberOfPeople(numPeople);
    setParticipants(Array(numPeople).fill({ name: "", age: "", gender: "male" }));
  };

  const handleParticipantChange = (index, field, value) => {
    const updatedParticipants = [...participants];
    updatedParticipants[index] = { ...updatedParticipants[index], [field]: value };
    setParticipants(updatedParticipants);
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    const options = {
      key: "rzp_test_wywb8ONB6LP3HN",
      amount: tourPrice * numberOfPeople * 100,
      currency: "INR",
      name: "Your Travel Company",
      description: "Tour Booking",
      image: "/your_logo.png",
      handler: function (response) {
        console.log("Payment successful:", response);
        if (response.razorpay_payment_id) {
          setPaymentStatus("success");
          setPaymentId(response.razorpay_payment_id);
        } else {
          setPaymentStatus("error");
          setPaymentId(""); // Reset paymentId in case of error
        }
        const dataToSend = {
          ...formData,
          recipientEmail: recipientEmail,
          paymentStatus: paymentStatus,
          paymentId: response.razorpay_payment_id,
          joinGroup: soloTravel ? joinGroup : null // Send joinGroup only if soloTravel is selected
        };
        sendDataToServer(dataToSend);
        console.log(dataToSend);
        navigate("/home");
      },
      prefill: { name: "Customer Name", email: "customer@example.com", contact: "9999999999" },
      theme: { color: "#3399cc" }
    };
    const rzp = new Razorpay(options);
    rzp.open();
  };

  const sendDataToServer = async (data) => {
    try {
      const userInfo = JSON.parse(localStorage.getItem("userInfo"));
      const recipientEmail = userInfo?.email || "";
      data.recipientEmail = recipientEmail;
      const response = await fetch("http://localhost/travelBooking/booking.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        console.log("Data sent successfully");
      } else {
        console.error("Failed to send data");
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };

  const formData = {
    groupTravel,
    soloTravel,
    joinGroup,
    participants,
    tourId: id,
    userId,
    paymentStatus,
    paymentId,
  };
  return (
    <Container>
      <h1 className="text-start py-3">Book Your Trip Now</h1>
      <div className="pb-5">
        <Form>
          <FormGroup tag="fieldset">
            <legend>Select Travelling Type:</legend>
            <FormGroup check>
              <Label check>
                <Input
                  type="checkbox"
                  name="groupTravel"
                  checked={groupTravel}
                  onChange={handleGroupTravelChange}
                />{" "}
                Group Travel
              </Label>
            </FormGroup>
            <FormGroup check>
              <Label check>
                <Input
                  type="checkbox"
                  name="soloTravel"
                  checked={soloTravel}
                  onChange={handleSoloTravelChange}
                />{" "}
                Solo Travel
              </Label>
            </FormGroup>
          </FormGroup>
          {soloTravel && (
            <FormGroup check>
              <Label check>
                <Input
                  type="checkbox"
                  name="joinGroup"
                  checked={joinGroup}
                  onChange={handleJoinGroupChange}
                />{" "}
                Join a Group
              </Label>
            </FormGroup>
          )}
                {soloTravel && (
            <>
              <FormGroup>
                <Label for="name">Name:</Label>
                <Input
                  type="text"
                  id="name"
                  name="name"
                  value={participants[0]?.name || ""}
                  onChange={(e) =>
                    handleParticipantChange(0, "name", e.target.value)
                  }
                />
              </FormGroup>
              <FormGroup>
                <Label for="age">Age:</Label>
                <Input
                  type="number"
                  id="age"
                  name="age"
                  value={participants[0]?.age || ""}
                  onChange={(e) =>
                    handleParticipantChange(0, "age", e.target.value)
                  }
                />
              </FormGroup>
              <FormGroup>
                <Label for="age">Phone:</Label>
                <Input
                  type="number"
                  id="phone"
                  name="phone"
                  value={participants[0]?.phone || ""}
                  onChange={(e) =>
                    handleParticipantChange(0, "phone", e.target.value)
                  }
                />
              </FormGroup>

              <FormGroup tag="fieldset">
                <legend>Gender:</legend>
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="gender"
                      value="male"
                      checked={participants[0]?.gender === "male"}
                      onChange={(e) =>
                        handleParticipantChange(0, "gender", e.target.value)
                      }
                    />{" "}
                    Male
                  </Label>
                </FormGroup>
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="gender"
                      value="female"
                      checked={participants[0]?.gender === "female"}
                      onChange={(e) =>
                        handleParticipantChange(0, "gender", e.target.value)
                      }
                    />{" "}
                    Female
                  </Label>
                </FormGroup>
              </FormGroup>
            </>
          )}
          {groupTravel && (
            <>
              <FormGroup>
                <Label for="numberOfPeople">Number of People:</Label>
                <Input
                  type="number"
                  id="numberOfPeople"
                  min={2}
                  name="numberOfPeople"
                  value={numberOfPeople}
                  onChange={handleNumberOfPeopleChange}
                />
              </FormGroup>
              {participants.map((participant, index) => (
                <div key={index}>
                  <FormGroup>
                    <Label for={`name${index}`}>{`Enter details of person ${
                      index + 1
                    }`}</Label>
                    <Input
                      type="text"
                      id={`name${index}`}
                      name={`name${index}`}
                      value={participant.name}
                      onChange={(e) =>
                        handleParticipantChange(index, "name", e.target.value)
                      }
                    />
                  </FormGroup>
                  <FormGroup>
                    <Label for={`age${index}`}>Age:</Label>
                    <Input
                      type="number"
                      id={`age${index}`}
                      name={`age${index}`}
                      value={participant.age}
                      min={1}
                      max={90}
                      onChange={(e) =>
                        handleParticipantChange(index, "age", e.target.value)
                      }
                    />
                  </FormGroup>
                  <FormGroup>
                    <Label for={`phone${index}`}>Phone:</Label>
                    <Input
                      type="number"
                      id={`phone${index}`}
                      name={`phone${index}`}
                      value={participant.phone}
                      min={10}
                      max={10}
                      onChange={(e) =>
                        handleParticipantChange(index, "phone", e.target.value)
                      }
                    />
                  </FormGroup>
                  <FormGroup tag="fieldset">
                    <legend>Gender:</legend>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="radio"
                          name={`gender${index}`}
                          value="male"
                          checked={participant.gender === "male"}
                          onChange={(e) =>
                            handleParticipantChange(
                              index,
                              "gender",
                              e.target.value
                            )
                          }
                        />{" "}
                        Male
                      </Label>
                    </FormGroup>
                    <FormGroup check>
                      <Label check>
                        <Input
                          type="radio"
                          name={`gender${index}`}
                          value="female"
                          checked={participant.gender === "female"}
                          onChange={(e) =>
                            handleParticipantChange(
                              index,
                              "gender",
                              e.target.value
                            )
                          }
                        />{" "}
                        Female
                      </Label>
                    </FormGroup>
                  </FormGroup>
                </div>
              ))}
            </>
          )}
          <Button type="submit" color="primary" onClick={handlePayment}>
            Submit
          </Button>
        </Form>
      </div>
    </Container>
  );
}

export default Booking;


