import React, { useEffect, useState } from "react";
import { Badge, Card, Container } from "reactstrap";

function TicketBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Retrieve user ID from local storage
    const userInfo = JSON.parse(localStorage.getItem("userInfo"));
    if (userInfo && userInfo.user_id) {
      fetchBookings(userInfo.user_id);
    }
  }, []);

  const fetchBookings = (userId) => {
    fetch(`http://localhost/travelBooking/travelTicket.php?userId=${userId}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "error") {
          setBookings([]);
          setLoading(false);
        } else {
          setBookings(data.bookings);
          setLoading(false);
        }
      })
      .catch((error) => console.error("Error fetching data:", error));
  };

  return (
    <div>
      <Container>
        <h1 className="text-center text-uppercase bg-light py-5">
          My Bookings
        </h1>
        {loading ? (
          <p>Loading...</p>
        ) : bookings.length === 0 ? (
          <h1>No Bookings Found</h1>
        ) : (
          bookings.map((booking) => (
            <div key={booking.bookingId} className="py-3">
              <Card className="d-flex p-4">
                <h2 className="text-center py-3">Travelling Ticket</h2>
                <div className="d-flex gap-2 justify-content-center align-items-center flex-">
                  <h4 className="text-uppercase fw-bold">From</h4>
                  <h4 className="text-center">{booking.origin}</h4>
                  <h4 className="fw-bold">To</h4>

                  <h4 className="text-center">{booking.destination}</h4>
                </div>

                <h2 className="text-center">
                  Total no.of People Travelling {booking.participants.length}
                </h2>
                <div className="d-flex flex-wrap gap-5 py-3">
                  {booking.participants.map((participant, index) => (
                    <div
                      key={participant.id}
                      className="bg-light shadow-sm border p-5 "
                    >
                      <h3>Person {index + 1}</h3>
                      <h5>Name: {participant.name}</h5>
                      <h5>Age: {participant.age}</h5>
                      <h5>Phone: {participant.phone}</h5>
                    </div>
                  ))}
                </div>
                <h5>
                  Payment Status:{" "}
                  {booking.paymentStatus === "success" ? (
                    <Badge color="success">Payment Successful</Badge>
                  ) : (
                    ""
                  )}
                </h5>
                <h5>Payment ID: {booking.paymentId}</h5>
              </Card>
            </div>
          ))
        )}
      </Container>
    </div>
  );
}

export default TicketBookings;
