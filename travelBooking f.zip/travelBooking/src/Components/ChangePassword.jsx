import React from "react";
import { Form } from "react-router-dom";
import { FormGroup, Input, Label } from "reactstrap";

function ChangePassword() {
  return (
    <>
      <Form>
        <FormGroup>
          <Label for="exampleEmail">Current Password</Label>
          <Input
            id="exampleEmail"
            name="email"
            placeholder="Enter Your Email"
            type="password"
            className="w-100"
          />
        </FormGroup>
        <FormGroup>
          <Label for="examplePassword"> New Password</Label>
          <Input
            id="examplePassword"
            name="newPassword"
            placeholder="Enter Your Password"
            type="password"
          />
        </FormGroup>
      </Form>
    </>
  );
}

export default ChangePassword;
