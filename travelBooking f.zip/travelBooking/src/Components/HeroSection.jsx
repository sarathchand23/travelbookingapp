import "../App.css";
import TicketSearch from "./TicketSearch";

const HeroSection = () => {
  return (
    <section className="heroSection">
      <div className=" h-100 w-100 ">
        <div className="container">
          <TicketSearch />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
