import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Container, Form, FormGroup, Input, Label } from "reactstrap";

function SignupPage() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const validateForm = () => {
    const errors = {};

    if (!email || !email.match(/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
      errors.email = "Email is not valid";
    }

    if (!password || password.length < 6 || password.length > 12) {
      errors.password = "Password must be between 6 and 12 characters";
    }

    if (password !== confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }

    if (!phone || !phone.match(/^\d{10}$/)) {
      errors.phone = "Phone number must be 10 digits";
    }

    setErrors(errors);

    return Object.keys(errors).length === 0;
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    const isValid = validateForm();

    if (isValid) {
      try {
        const response = await fetch(
          "http://localhost/travelBooking/signup.php",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: name,
              email: email,
              phone: phone,
              password: password,
            }),
            // mode: "no-cors",
          }
        );
        console.log("Response:", response);

        // const responseData = await response.json();

        if (response.status === 200) {
          console.log(response)
          console.log("Signup successful!"); // Log success message
          navigate("/");
        } else {
    
        }
      } catch (error) {
        console.error("Error:", error);
        // Handle error in case of network failure or other issues
      }
    }
  };

  return (
    <>
      <div className=" py-3 loginBackground ">
        <Container className="loginContainer p-4 rounded ">
          <h2 className="text-center text-uppercase text-white">Sign up</h2>
          <Form>
            <FormGroup>
              <Label for="exampleEmail" className="text-white fs-5 text-uppercase fw-bold text-upppercase">Name</Label>
              <Input
                id="exampleName"
                name="name"
                placeholder="Enter Your Name"
                type="text"
                className="w-100"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              {errors.email && (
                <span className="text-danger">{errors.email}</span>
              )}
            </FormGroup>

            <FormGroup>
              <Label for="exampleEmail" className="text-white fs-5 text-uppercase fw-bold text-upppercase">Email</Label>
              <Input
                id="exampleEmail"
                name="email"
                placeholder="Enter Your Email"
                type="email"
                className="w-100"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              {errors.email && (
                <span className="text-danger">{errors.email}</span>
              )}
            </FormGroup>
            <FormGroup>
              <Label for="examplePhone" className="text-white fs-5 text-uppercase fw-bold text-upppercase">Phone</Label>
              <Input
                id="examplePhone"
                name="phone"
                placeholder="Enter Your Phone Number"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
              {errors.password && (
                <span className="text-danger">{errors.password}</span>
              )}
            </FormGroup>
            <FormGroup>
              <Label for="examplePassword" className="text-white fs-5 text-uppercase fw-bold text-upppercase">Password</Label>
              <Input
                id="examplePassword"
                name="password"
                placeholder="Enter Your Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {errors.password && (
                <span className="text-danger">{errors.password}</span>
              )}
            </FormGroup>
            <FormGroup>
              <Label for="exampleConfirmPassword" className="text-white fs-5 text-uppercase fw-bold text-upppercase">Confirm Password</Label>
              <Input
                id="exampleConfirmPassword"
                name="confirmPassword"
                placeholder="Confirm Password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
              {errors.confirmPassword && (
                <span className="text-danger">{errors.confirmPassword}</span>
              )}
            </FormGroup>

            <p>
              <a href="" onClick={() => navigate("/")} className="text-white">
                Do you have an account ? Login from Here
              </a>
            </p>
            <div className="text-center">
              <Button
                size=""
                color="success"
                className="text-uppercase mt-3"
                onClick={handleSignup}
              >
                Signup
              </Button>
            </div>
          </Form>
        </Container>
      </div>
    </>
  );
}

export default SignupPage;
