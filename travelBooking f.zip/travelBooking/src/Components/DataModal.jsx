import React from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";

function DataModal({
  showModal,
  handleModalClose,
  handleModalSave,
  modalData,
  setModalData,
  modalType,
  modalMode,
  handleTicketAdd,
}) {
  console.log(modalData)
  return (
    <>
      <Modal isOpen={showModal} toggle={handleModalClose}>
        <ModalHeader toggle={handleModalClose}>
          {modalMode === "add" ? "Add New Data" : "Edit Data"}
        </ModalHeader>
        <ModalBody>
          <form>
            {modalType === "tours" && (
              <>
                <div className="mb-3">
                  <label htmlFor="nameOfTheTrip" className="form-label">
                    Name Of The Trip
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="nameOfTheTrip"
                    value={modalData?.nameOfTheTrip || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        nameOfTheTrip: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="price" className="form-label">
                    Price
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="price"
                    min={1}
                    value={modalData?.price || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        price: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="location" className="form-label">
                    Location
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="location"
                    value={modalData?.location || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        location: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="description" className="form-label">
                    Description
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="description"
                    value={modalData?.description || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        description: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="itinerary" className="form-label">
                    Itinerary
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="itinerary"
                    value={modalData?.itinerary || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        itinerary: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="allowedBookings" className="form-label">
                    Allowed Bookings
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="allowedBookings"
                    value={modalData?.allowedBookings || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        allowedBookings: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="noOfSoloTravelers" className="form-label">
                    No . of Solo Travellers
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="noOfSoloTravelers"
                    value={modalData?.noOfSoloTravelers || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        noOfSoloTravelers: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="noOfDays" className="form-label">
                    No . of Days
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="noOfDays"
                    value={modalData?.noOfDays || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        noOfDays: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="noOfNights" className="form-label">
                    No . of Nights
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="noOfNights"
                    value={modalData?.noOfNights || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        noOfNights: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="noOfBookingsLeft" className="form-label">
                    No . of Bookings left
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="noOfBookingsLeft"
                    value={modalData?.noOfBookingsLeft || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        noOfBookingsLeft: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="totalBookings" className="form-label">
                    Total Bookings
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="totalBookings"
                    value={modalData?.totalBookings || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        totalBookings: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="date" className="form-label">
                    Dates
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="date"
                    value={modalData?.date || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        date: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="tripImage" className="form-label">
                    trip Image
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="tripImage"
                    value={modalData?.tripImage || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        tripImage: e.target.value,
                      })
                    }
                  />
                </div>
                {/* Render fields for tours */}
              </>
            )}
            {modalType === "travelOptions" && (
              <>
                <div className="mb-3">
                  <label htmlFor="option_name" className="form-label">
                    Enter Comnpany Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="option_name"
                    value={modalData?.option_name || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        option_name: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="origin" className="form-label">
                    Enter origin
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="origin"
                    value={modalData?.origin || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, origin: e.target.value })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="destination" className="form-label">
                    Enter Destination
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="destination"
                    value={modalData?.destination || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        destination: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="bus_seats_available " className="form-label">
                    No.Of Bus Tickets
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="bus_seats "
                    value={modalData?.bus_seats_available || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        bus_seats_available: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="train_seats_available " className="form-label">
                    No.Of Train Tickets
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="train_seats "
                    value={modalData?.train_seats_available || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        train_seats_available: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="flight_seats_available" className="form-label">
                    No.Of Flight Tickets
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="flight_seats_available "
                    value={modalData?.flight_seats_available || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        flight_seats_available: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="bus_price" className="form-label">
                    Bus Price
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="bus_price"
                    value={modalData?.bus_price || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, bus_price: e.target.value })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="train_price" className="form-label">
                    Train Price
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="train_price"
                    value={modalData?.train_price || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        train_price: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="flight_price" className="form-label">
                    Flight Price
                  </label>
                  <input
                    type="number"
                    min={1}
                    className="form-control"
                    id="flight_price"
                    value={modalData?.flight_price || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        flight_price: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="bus_name" className="form-label">
                    Enter Bus Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="bus_name"
                    value={modalData?.bus_name || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, bus_name: e.target.value })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="train_name" className="form-label">
                    Enter Train Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="train_name"
                    value={modalData?.train_name || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, train_name: e.target.value })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="flight_name" className="form-label">
                    Enter Flight Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="flight_name"
                    value={modalData?.flight_name || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        flight_name: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="cab_name" className="form-label">
                    Enter Cab Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="cab_name"
                    value={modalData?.cab_name || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        cab_name: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="cab_price" className="form-label">
                    Enter Cab Price
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="cab_price"
                    value={modalData?.cab_price || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        cab_price: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="cab_seats_available" className="form-label">
                    No.of Cab Seats
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="cab_seats_available"
                    value={modalData?.cab_seats_available || ""}
                    onChange={(e) =>
                      setModalData({
                        ...modalData,
                        cab_seats_available: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="start_date" className="form-label">
                    Start Date
                  </label>
                  <input
                    type="date"
                    className="form-control"
                    id="start_date"
                    value={modalData?.start_date || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, start_date: e.target.value })
                    }
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="end_date" className="form-label">
                    Start Date
                  </label>
                  <input
                    type="date"
                    className="form-control"
                    id="end_date"
                    value={modalData?.end_date || ""}
                    onChange={(e) =>
                      setModalData({ ...modalData, end_date: e.target.value })
                    }
                  />
                </div>
              </>
            )}
          </form>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={handleModalClose}>
            Cancel
          </Button>
          <Button color="primary" onClick={() => handleModalSave(modalData)}>
            Save
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}

export default DataModal;
