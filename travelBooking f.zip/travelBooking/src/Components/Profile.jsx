import React from 'react'

function Profile() {
  return (
    <>
        
    </>
  )
}

export default Profile