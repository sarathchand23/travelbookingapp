import DataTable from "react-data-table-component";
import { Button } from "reactstrap";
import DataModal from "./DataModal";

function CommonDataTable({
  title,
  data,
  columns,
  handleAdd,
  showModal,
  handleModalClose,
  handleModalSave,
  modalData,
  modalType,
}) {
  return (
    <div className="py-5">
      {modalType === "tours"  && ( 
        <div className="text-end">
          <Button onClick={handleAdd} className="text-end">
            Add New
          </Button>
        </div>
      )}
        {modalType === "travelOptions"  && ( 
        <div className="text-end">
          <Button onClick={handleAdd} className="text-end">
            Add New
          </Button>
        </div>
      )}
      <DataTable columns={columns} data={data} title={title} pagination />
      <DataModal
        showModal={showModal}
        handleModalClose={handleModalClose}
        handleModalSave={handleModalSave}
        modalData={modalData}
        modalType={modalType}
        
      />
    </div>
  );
}

export default CommonDataTable;
