import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Container, Form, FormGroup, Input, Label } from "reactstrap";

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [userInfo, setUserInfo] = useState(null); // State to store user information
  // Function to handle login
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost/travelBooking/login.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data.userInfo);
        setToken(data.token); // Store the JWT token in state
        localStorage.setItem("userInfo", JSON.stringify(data.userInfo)); // Convert object to string before storing
        localStorage.setItem("token", data.token); // Store the JWT token in local storage
        setUserInfo(data.userInfo); // Set user info state
        navigate("/home"); // Redirect to home page after successful login
      } else {
        const data = await response.json();
        alert(data.message); // Show error message if login fails
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Function to check if user is already logged in
  const checkLoggedIn = () => {
    const storedToken = localStorage.getItem("token");
    if (storedToken) {
      setToken(storedToken);
      navigate("/home");
    }
  };

  // useEffect hook to check if user is already logged in when the component mounts
  useEffect(() => {
    checkLoggedIn();
  }, []); 
  // Empty dependency array ensures this effect runs only once when component mounts

  return (
    <>
      <div className="py-5 ">
        <Container className=" loginContainer p-5 rounded  mt-5">
          <h2 className="text-center text-uppercase fw-bold text-white">Login To Start Booking</h2>
          <Form onSubmit={handleSubmit}>
            <FormGroup>
              <Label for="exampleEmail " className="fs-4 text-uppercase fw-bold text-white">Email</Label>
              <Input
                id="exampleEmail"
                name="email"
                placeholder="Enter Your Email"
                type="email"
                className="w-100"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </FormGroup>
            <FormGroup>
              <Label for="examplePassword" className="text-white fw-bold fs-4 text-uppercase">Password</Label>
              <Input
                id="examplePassword"
                name="password"
                placeholder="Enter Your Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </FormGroup>
            <p>
              <a href="#" onClick={() => navigate("/signup")} className="text-white">
                Don't you have an account ? Create One from Here
              </a>
            </p>
            <div className="text-center">
              <Button
                size=""
                color="success"
                className="text-uppercase mt-3"
                type="submit"
              >
                Login
              </Button>
            </div>
          </Form>
        </Container>
      </div>
    </>
  );
}

export default Login;
