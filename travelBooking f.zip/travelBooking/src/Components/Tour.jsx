import { useState, useEffect } from "react";
import { Badge, Container } from "reactstrap";
import { useParams } from "react-router-dom";
import { WiDaySunny } from "react-icons/wi";
import { MdNightsStay } from "react-icons/md";
import { formatCurrency } from "../utilities/formatCurrency";

function Tour() {
  const { id } = useParams(); // Fetch the ID from the URL params
  const [tourData, setTourData] = useState(null);
  useEffect(() => {
    // Fetch data from the API based on the provided ID
    fetch(`http://localhost/travelBooking/tour.php?id=${id}`)
      .then((response) => response.json())
      .then((data) => {
        // Once data is fetched, set it to the state
        setTourData(data);
      })
      .catch((error) => {
        console.error("Error fetching tour data:", error);
      });
  }, [id]); // Run effect whenever the ID changes

  return (
    <>
      {tourData && (
        <Container>
          <div className="d-flex  justify-content-around align-items-between gap-5 flex- align-items- py-5">
            <div className="text-">
              <img
                src={tourData?.tripImage}
                alt={tourData.nameOfTheTrip}
                className="rounded"
              />
            </div>
            <div className="pb-5">
              <h1 className="text-center">{tourData.nameOfTheTrip}</h1>
              <p className="fs-5"> {tourData.description}</p>
              <div className="d-flex gap-5">
                <div className="d-flex justify-content-center gap-1   px-3  align-items-center bg-secondary-subtle rounded shadow-md ">
                  <WiDaySunny size={35} />
                  <p className="fs-4 fw-bold pt-3">{tourData.noOfDays}</p>
                  <p className="fs-4 fw-bold pt-3">Days</p>
                </div>
                <div className="d-flex justify-content-center gap-1  px-3 align-items-center bg-secondary-subtle rounded shadow-md ">
                  <MdNightsStay size={25} />

                  <p className="fs-4 fw-bold pt-3">{tourData.noOfNights}</p>
                  <p className="fs-4 fw-bold pt-3">Nights</p>
                </div>
              </div>
              <Badge className=" mt-4 fs-4 fw-bold bg-success ">
                {tourData.allowedBookings} Seats Availble
              </Badge>
              <p className="fs-4 mt-3 bg-success-subtle p-3 rounded">
                {formatCurrency(tourData.price)} /person
              </p>
              <p className=" text-danger">
                *Disclaimer: No cancellation allowed{" "}
              </p>
            </div>
          </div>
          <div>
            <h2 className="text-center text-uppercase">Itinerary</h2>
            <h4 className="bg-primary-subtle p-3 rounded">{tourData.itinerary}</h4>
          </div>
        </Container>
      )}
    </>
  );
}

export default Tour;
