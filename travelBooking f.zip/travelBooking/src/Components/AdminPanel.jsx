import { useEffect, useState } from "react";
import CommonDataTable from "./CommonDataTable";
import { AiOutlineEdit } from "react-icons/ai";
import { AiOutlineDelete } from "react-icons/ai";
import DataModal from "./DataModal";
import Swal from "sweetalert2";
import { formatCurrency } from "../utilities/formatCurrency";
function AdminPanel() {
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState({});
  const [modalMode, setModalMode] = useState("");
  const [modalType, setModalType] = useState("");
  const [customers, setCustomers] = useState([]);
  const [tours, setTours] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [tickets, setTickets] = useState([]);
  const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: "btn btn-success me-5",
      cancelButton: "btn btn-danger",
    },
    buttonsStyling: false,
  });

  const handleDelete = (row, hi) => {
    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You won't be able to get back!",
        icon: "warning",
        showCancelButton: true,
        cancelButtonText: "No, cancel!",
        confirmButtonText: "Yes, delete it!",
        reverseButtons: false,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          let response;
          try {
            if (hi === "travelOptions") {
              response = await fetch(
                "http://localhost/travelBooking/ticketBooking.php",
                {
                  method: "DELETE",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({ id: row.id }), // Assuming row.id contains the ID of the tour to delete
                }
              );
            } else {
              response = await fetch(
                "http://localhost/travelBooking/tour.php",
                {
                  method: "DELETE",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({ id: row.id }), // Assuming row.id contains the ID of the tour to delete
                }
              );
            }

            if (response.ok) {
              // Remove the deleted tour from the state
              setTours((prevTours) =>
                prevTours.filter((tour) => tour.id !== row.id)
              );
              fetchTours();
              fetchTickets();

              swalWithBootstrapButtons.fire(
                "Deleted!",
                "The tour has been deleted.",
                "success"
              );
            } else {
              throw new Error("Failed to delete tour");
            }
          } catch (error) {
            console.error("Error deleting tour:", error);
            swalWithBootstrapButtons.fire(
              "Error",
              "Failed to delete the tour.",
              "error"
            );
          }
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire("Cancelled", "Your action was cancelled.", "error");
        }
      });
  };

  const customersColumns = [
    { name: "User Id", selector: (row) => row.id, sortable: true },
    { name: "Name", selector: (row) => row.name, sortable: true },
    { name: "Email", selector: (row) => row.email, sortable: true },
    {
      name: "Mobile number",
      selector: (row) => row.phone,
    },
    {
      name: "Role",
      selector: (row) => row.role,
    },
  ];
  const toursColumns = [
    {
      name: "Price",
      selector: (row) => formatCurrency(row.price),
      width: "150px",
    },
    {
      name: "Tour Id",
      selector: (row) => row.id,
      width: "150px",
    },
    {
      name: "Name of the trip",
      selector: (row) => row.nameOfTheTrip,
      width: "200px",
    },
    {
      name: "Description",
      selector: (row) => row.description,
      width: "400px",
    },
    {
      name: "Itinerary",
      selector: (row) => row.itinerary,
      width: "400px",
    },
    { name: "Location", selector: (row) => row.location, sortable: true },
    {
      name: "Allowed bookings",
      selector: (row) => row.allowedBookings,
    },
    {
      name: "No.of Solo travelers",
      selector: (row) => row.noOfSoloTravelers,
    },

    {
      name: "No. of days for a trip",
      selector: (row) => row.noOfDays,
    },
    {
      name: "No. of nights for a trip",
      selector: (row) => row.noOfNights,
    },

    {
      name: "No. of bookings left",
      selector: (row) => row.noOfBookingsLeft,
    },
    {
      name: "Dates",
      selector: (row) => row.date,
    },
    {
      name: "Image  URL",
      selector: (row) => row.tripImage,
    },
    {
      name: "Action",
      cell: (row) => (
        <>
          <span
            className="text-primary me-2"
            onClick={() => handleEdit(row, "tours")}
          >
            <AiOutlineEdit size={20} />
          </span>
          <span className="text-danger" onClick={() => handleDelete(row)}>
            <AiOutlineDelete size={20} />
          </span>
        </>
      ),
    },
  ];
  const bookingsColumn = [
    {
      name: "Booking ID",
      selector: (row) => row.bookingId,
      sortable: true,
    },
    {
      name: "Trip Name",
      selector: (row) => row.tours.nameOfTheTrip,
      sortable: true,
    },
    {
      name: "Location",
      selector: (row) => row.tours.location,
      sortable: true,
    },
    
      {
        name: "Willing to join in a group",
        cell: (row) => row.tours.join_group ? "Yes" : "No",
        sortable: true,
      },
      
  
    {
      name: "Participants",
      selector: (row) => row.participants.length,
      sortable: true,
    },
    {
      name: "Payment Status",
      cell: (row) => {
        let statusBadge;
        switch (row.paymentStatus) {
          case "success":
            statusBadge = (
              <span className="badge bg-success">Payment successful</span>
            );
            break;
          case "fail":
            statusBadge = (
              <span className="badge bg-danger">Payment Failed</span>
            );
            break;
          default:
            statusBadge = (
              <span className="badge bg-warning">
                Payment confirmation pending
              </span>
            );
            break;
        }
        return statusBadge;
      },
      sortable: true,
    },
    {
      name: "Payment ID",
      selector: (row) => row.payment_id,
      sortable: true,
    },
    {
      name: "Participants Details",
      cell: (row) => {
        // Map through participants array and format their details
        return row.participants.map((participant, index) => (
          <div key={index}>
            <p>Name: {participant.name}</p>
            <p>Phone: {participant.phone}</p>
            <p>Age: {participant.age}</p>
          </div>
        ));
      },
    },
  ];
  const ticketsColumn = [
    {
      name: "Company Name",
      selector: (row) => row.option_name,
      sortable: true,
    },
    {
      name: "Origin",
      selector: (row) => row.origin,
      sortable: true,
    },
    {
      name: "Destination",
      selector: (row) => row.destination,
      sortable: true,
    },
    {
      name: "Flight Name",
      selector: (row) => row.flight_name,
      sortable: true,
    },
    {
      name: "No.of Flight Tickets",
      selector: (row) => row.flight_seats_available,
      sortable: true,
    },
    {
      name: "Flight Price /Person ",
      selector: (row) => formatCurrency(row.flight_price),
      sortable: true,
    },
    {
      name: "Train Name",
      selector: (row) => row.train_name,
      sortable: true,
    },

    {
      name: "No.of Train Tickets",
      selector: (row) => row.train_seats_available,
      sortable: true,
    },
    {
      name: "Train Price /Person ",
      selector: (row) => formatCurrency(row.train_price),
      sortable: true,
    },
    {
      name: "Bus Name",
      selector: (row) => row.bus_name,
      sortable: true,
    },
    {
      name: "No.of Bus Tickets",
      selector: (row) => row.bus_seats_available,
      sortable: true,
    },
    {
      name: "Bus Price /Person ",
      selector: (row) => formatCurrency(row.bus_price),
      sortable: true,
    },
    {
      name: " Cab Name",
      selector: (row) => row.cab_name,
      sortable: true,
    },
    {
      name: " Cab Price",
      selector: (row) => row.cab_price,
      sortable: true,
    },
    {
      name: " Cab Seats",
      selector: (row) => row.cab_seats_available,
      sortable: true,
    },

    {
      name: "Start Date ",
      selector: (row) => row.start_date,
      sortable: true,
    },
    {
      name: "End Date ",
      selector: (row) => row.end_date,
      sortable: true,
    },
    {
      name: "Action",
      cell: (row) => (
        <>
          <span
            className="text-primary me-2"
            onClick={() => handleEdit(row, "travelOptions")}
          >
            <AiOutlineEdit size={20} />
          </span>
          <span
            className="text-danger"
            onClick={() => handleDelete(row, "travelOptions")}
          >
            <AiOutlineDelete size={20} />
          </span>
        </>
      ),
    },
  ];
  useEffect(() => {
    // Fetch customers data when component mounts
    fetchCustomers();
    fetchTours();
    fetchBookings();
    fetchTickets();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch(
        "http://localhost/travelBooking/getAllusers.php"
      );
      if (response.ok) {
        const data = await response.json();
        setCustomers(data.users);
      } else {
        console.error("Failed to fetch customers");
      }
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };
  const fetchTours = async () => {
    try {
      const response = await fetch("http://localhost/travelBooking/tour.php");
      if (response.ok) {
        const data = await response.json();
        setTours(data);
      } else {
        console.error("Failed to fetch customers");
      }
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };
  const fetchBookings = async () => {
    try {
      const response = await fetch(
        "http://localhost/travelBooking/booking.php?allbookings"
      );
      if (response.ok) {
        const data = await response.json();
        setBookings(data);
      } else {
        console.error("Failed to fetch bookings");
      }
    } catch (error) {
      console.error("Error fetching bookings:", error);
    }
  };
  const fetchTickets = async () => {
    try {
      const response = await fetch(
        "http://localhost/travelBooking/ticketBooking.php"
      );
      if (response.ok) {
        const data = await response.json();
        setTickets(data);
      } else {
        console.error("Failed to fetch bookings");
      }
    } catch (error) {
      console.error("Error fetching bookings:", error);
    }
  };
  const handleEdit = (row, type) => {
    // Ensure to copy the row data
    const rowData = { ...row };
    setModalData(rowData);
    setModalType(type);
    setShowModal(true);
    setModalMode("edit");
  };

  const handleModalClose = () => {
    setShowModal(false);
  };
  const handleModalSave = async (data) => {
    try {
      let url = "http://localhost/travelBooking/tour.php";
      let method = "POST"; // Default method is POST for adding new trip

      if (modalMode === "edit") {
        if (modalType === "tours") {
          // Include the tour ID in the request body for PUT request
          url = "http://localhost/travelBooking/tour.php";
          method = "PUT";
          data = { id: data.id, data: { ...data } }; // Construct the request body for edit mode
        } else if (modalType === "travelOptions") {
          // Include the travel option ID in the request body for PUT request
          url = "http://localhost/travelBooking/ticketBooking.php";
          method = "PUT";
          data = { id: data.id, ...data }; // Assuming the data contains all necessary fields for travel options
        }
      } else if (modalType === "travelOptions") {
        // Set URL and method for travel options
        url = "http://localhost/travelBooking/ticketBooking.php";
        method = "POST"; // Assuming you are adding new travel options
      }

      const response = await fetch(url, {
        method: method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        // If successful, refresh the data accordingly
        if (modalType === "tours") {
          fetchTours();
        } else if (modalType === "travelOptions") {
          fetchTickets();
        }
        setShowModal(false);
      } else {
        throw new Error("Failed to save data");
      }
    } catch (error) {
      console.error("Error saving data:", error);
    }
  };

  const handleAdd = () => {
    setShowModal(true);
    setModalType("tours");

    setModalMode("add");
  };
  const handleTicketAdd = () => {
    setShowModal(true);
    setModalType("travelOptions");
    setModalMode("add");
  };
  return (
    <div className="container py-5">
      <CommonDataTable
        title="Customers"
        data={customers}
        columns={customersColumns}
      />

      <CommonDataTable
        title="Tours"
        data={tours}
        handleAdd={handleAdd} // Pass the type here
        columns={toursColumns}
        modalType="tours" // Pass modalType prop
      />
      <CommonDataTable
        title="Bookings"
        data={bookings}
        columns={bookingsColumn}
      />
      <CommonDataTable
        title="Travel Tickets"
        data={tickets}
        handleAdd={handleTicketAdd}
        columns={ticketsColumn}
        modalType="travelOptions"
      />
      <DataModal
        showModal={showModal}
        handleModalClose={handleModalClose}
        handleModalSave={handleModalSave}
        modalData={modalData}
        modalType={modalType}
        setModalData={setModalData}
        modalMode={modalMode}
      />
    </div>
  );
}

export default AdminPanel;
